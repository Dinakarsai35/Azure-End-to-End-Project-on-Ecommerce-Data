# Databricks notebook source
# MAGIC %md
# MAGIC ### Data Reading

# COMMAND ----------

df = spark.read.format('parquet').option('inferSchema',True)\
    .load('abfss://bronze@dinakarecommercedatalake.dfs.core.windows.net/rawdata')


# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Data Transformations

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, to_date, date_format, col, expr

# COMMAND ----------

# MAGIC %md
# MAGIC ### Splitting Date and Time Columns

# COMMAND ----------

df = df.withColumn('Invoice Date',to_date('InvoiceDate'))\
    .withColumn('Invoice Time', date_format('InvoiceDate', 'HH:mm:ss'))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.drop('InvoiceDate')
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cleaning and Formating Description Data

# COMMAND ----------

from pyspark.sql.functions import regexp_replace
df = df.withColumn(
    "Description",
    regexp_replace(col("Description"), r"SET\s*[/\-]?\s*(\d+)", r"SET for \1")
)

# COMMAND ----------

df = df.withColumn(
    "Description",
    regexp_replace(col("Description"), r"\+", "&")
)

# COMMAND ----------

df.display()

# COMMAND ----------

from pyspark.sql.functions import initcap, trim

# COMMAND ----------

# MAGIC %md
# MAGIC ### Removing trailing spacess from description and using initcap

# COMMAND ----------

df = df.withColumn('Description', initcap('Description'))\
    .withColumn('Description', trim('Description'))

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Convert Data Types of columns

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

df.printSchema

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn('Quantity', col('Quantity').cast(IntegerType()))\
    .withColumn('UnitPrice', col('UnitPrice').cast(DecimalType(10,2)))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn('Total Price', col('Quantity')* col('UnitPrice'))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn('Transaction Type', when(col('Quantity') < 0, 'Return').otherwise('Sale'))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.fillna({'CustomerID': 'Not Available','Description': 'Not Available'})

# COMMAND ----------

df = df.withColumn("Description", regexp_replace(col("Description"), r'"', ''))

# COMMAND ----------

df.display()

# COMMAND ----------

df.groupBy("Country", "Invoice Date","Transaction Type") \
  .agg(
      sum("Total Price").alias("TotalSales"),
      sum("Quantity").alias("TotalQuantity")
  ) \
  .orderBy("Country", "Invoice Date") \
  .display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Writing

# COMMAND ----------

df.write.format('Parquet')\
    .mode('overwrite')\
        .option('path','abfss://silver@dinakarecommercedatalake.dfs.core.windows.net/EcommerceSales')\
            .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Querying Silver Data

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from parquet.`abfss://silver@dinakarecommercedatalake.dfs.core.windows.net/EcommerceSales/`

# COMMAND ----------

