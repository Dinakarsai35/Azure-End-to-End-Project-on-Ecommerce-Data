# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Flag Parameter

# COMMAND ----------

dbutils.widgets.text('incremental_flag','0')

# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')
print(incremental_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating Dimension Customer

# COMMAND ----------

df_src = spark.sql('''
SELECT distinct(CustomerID) as CustomerID, Country, `Transaction Type` 
FROM parquet.`abfss://silver@dinakarecommercedatalake.dfs.core.windows.net/EcommerceSales/`
''')


# COMMAND ----------

df_src.display()

# COMMAND ----------

if  spark.catalog.tableExists('ecommerce_catalog.gold.dim_customer'):

    df_sink = spark.sql('''
                        
    SELECT dim_customer_key, CustomerID, Country, TransactionType 
    FROM ecommerce_catalog.gold.dim_customer
    

    ''')
else:
    df_sink = spark.sql('''
                        
    SELECT 1 as dim_customer_key, CustomerID, Country, `Transaction Type`  
    FROM parquet.`abfss://silver@dinakarecommercedatalake.dfs.core.windows.net/EcommerceSales/`
    where 1 =0

    ''')

# COMMAND ----------

df_sink.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Filtering New and Old records

# COMMAND ----------

df_filter = df_src.join(df_sink, df_src['CustomerID'] == df_sink['CustomerID'], 'left').select(df_src['CustomerID'], df_src['Country'],df_src['Transaction Type'], df_sink['dim_customer_key'])


# COMMAND ----------

df_filter.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###df_filter old

# COMMAND ----------

df_filter_old = df_filter.filter(col('dim_customer_key').isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC #### df_filter_new

# COMMAND ----------

df_filter_new = df_filter.filter(col('dim_customer_key').isNull()).select(df_src['CustomerID'], df_src['Country'], df_src['Transaction Type'])

# COMMAND ----------

df_filter_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Create Surrogate Key

# COMMAND ----------

if incremental_flag == '0':
    max_value = 1
else:
    max_value_df = spark.sql('''select max(dim_customer_key) from ecommerce_catalog.gold.dim_customer''')
    max_value = max_value_df.collect()[0][0] 


# COMMAND ----------

df_filter_new = df_filter_new.withColumn('dim_customer_key', max_value + monotonically_increasing_id())

# COMMAND ----------

df_filter_new.display()

# COMMAND ----------

df_final = df_filter_new.union(df_filter_old)

# COMMAND ----------

df_final = df_final.withColumnRenamed("Transaction Type", "TransactionType")
df_final = df_final.dropDuplicates(["dim_customer_key"])

df_final.display()

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Slowly Changing Dimensions - Type:1 (Upsert)

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

#incremental Run
if  spark.catalog.tableExists('ecommerce_catalog.gold.dim_customer'):
    delta_tbl = DeltaTable.forPath(spark, 'abfss://gold@dinakarecommercedatalake.dfs.core.windows.net/dim_customer/')
    delta_tbl.alias('tgt').merge(df_final.alias('src'), 'tgt.dim_customer_key = src.dim_customer_key')\
        .whenMatchedUpdateAll()\
            .whenNotMatchedInsertAll()\
                .execute()

#Initial Run
else:
    df_final.write.format("delta")\
        .mode('overwrite')\
            .option('path', 'abfss://gold@dinakarecommercedatalake.dfs.core.windows.net/dim_customer/')\
                .saveAsTable('ecommerce_catalog.gold.dim_customer')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ecommerce_catalog.gold.dim_customer;

# COMMAND ----------

