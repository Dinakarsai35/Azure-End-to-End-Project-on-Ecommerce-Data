# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Creating Fact Table

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading Data From Silver Table

# COMMAND ----------


df_silver = spark.sql(
  '''
  select * from parquet.`abfss://silver@dinakarecommercedatalake.dfs.core.windows.net/EcommerceSales`
  '''
)

# COMMAND ----------

df_silver.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading all the dimensions

# COMMAND ----------

df_product = spark.sql("select * from ecommerce_catalog.gold.dim_product")
df_customer = spark.sql("select * from ecommerce_catalog.gold.dim_customer")
#df_date = spark.sql("select * from ecommerce_catalog.gold.dim_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bringing Keys to the Fact Table

# COMMAND ----------

df_fact = df_silver.join(df_customer,df_silver['CustomerID'] == df_customer['CustomerID'],'left').join(df_product,df_silver['StockCode'] == df_product['StockCode'],'left').select(df_silver['Quantity'], df_silver['UnitPrice'] , df_silver['Total Price'], df_customer['dim_customer_key'],  df_product['dim_product_key'] )

# COMMAND ----------

df_fact = df_fact.withColumnRenamed('Total Price', 'TotalPrice')
df_fact = df_fact.dropDuplicates([ "dim_customer_key", "dim_product_key"])

df_fact.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Fact Table

# COMMAND ----------

df_fact = df_fact.repartition(16)


# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

from delta.tables import DeltaTable

# Incremental Run
if spark.catalog.tableExists('ecommerce_catalog.gold.factsales'):
    delta_tbl = DeltaTable.forPath(
        spark,
        'abfss://gold@dinakarecommercedatalake.dfs.core.windows.net/factsales/'
    )
    
    delta_tbl.alias('tgt').merge(
        df_fact.alias('src'),
        '''
        
        tgt.dim_customer_key = src.dim_customer_key AND
        tgt.dim_product_key = src.dim_product_key
        '''
    ) \
    .whenMatchedUpdateAll() \
    .whenNotMatchedInsertAll() \
    .execute()

# Initial Run
else:
    df_fact.write.format("delta") \
    .mode("overwrite") \
    .option("path", "abfss://gold@dinakarecommercedatalake.dfs.core.windows.net/factsales/") \
    .saveAsTable("ecommerce_catalog.gold.factsales")



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ecommerce_catalog.gold.factsales