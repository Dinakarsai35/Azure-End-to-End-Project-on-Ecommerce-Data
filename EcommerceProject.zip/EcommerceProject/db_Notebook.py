# Databricks notebook source
# MAGIC %md
# MAGIC ### Create Catalog
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create catalog ecommerce_catalog;

# COMMAND ----------

# MAGIC %md
# MAGIC ####Create Schema

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema ecommerce_catalog.silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema ecommerce_catalog.gold;